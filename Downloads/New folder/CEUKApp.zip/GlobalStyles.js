/* fonts */
export const FontFamily = {
  poppinsRegular: "Poppins-Regular",
};
/* font sizes */
export const FontSize = {
  size_lg: 18,
  size_mini: 15,
};
/* Colors */
export const Color = {
  colorWhite: "#fff",
  colorDarkslategray: "#0a3b56",
  colorGainsboro: "#d9d9d9",
};
/* border radiuses */
export const Border = {
  br_3xs: 10,
};
